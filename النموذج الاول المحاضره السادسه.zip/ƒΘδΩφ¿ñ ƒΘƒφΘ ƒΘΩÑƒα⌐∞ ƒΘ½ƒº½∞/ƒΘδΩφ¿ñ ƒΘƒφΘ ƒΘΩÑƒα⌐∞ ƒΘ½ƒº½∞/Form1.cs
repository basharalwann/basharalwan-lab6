﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace النموذج_الاول_المحاضره_السادسه
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Width = pictureBox1.Height = 300;
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.BackColor = Color.Red;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Image = Image.FromFile(@"IMG_220.jpg");
            pictureBox1.BackgroundImage = Image.FromFile(@"IMG_20231026_202428_580.jpg");
            toolTip1.SetToolTip(pictureBox1, "pictureBox اداة");
            this.AutoSize = true;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
           // pictureBox1.BackgroundImage = null; لحذف خلفية الصوره
        }
        
    }
}
