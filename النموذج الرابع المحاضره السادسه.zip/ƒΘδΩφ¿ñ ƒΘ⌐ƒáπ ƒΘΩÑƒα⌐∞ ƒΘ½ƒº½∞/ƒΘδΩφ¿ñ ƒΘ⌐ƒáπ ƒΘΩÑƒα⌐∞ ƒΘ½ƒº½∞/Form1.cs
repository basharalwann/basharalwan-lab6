﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace النموذج_الرابع_المحاضره_السادسه
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //هذا المربع
        int s=80;
        private void button1_Click(object sender, EventArgs e)
        {//رسم المربع فيpictureBox1  
            Bitmap myb = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            int x = 20;
            int y = 50;
            for (int i = 0; i < s; i++)
            {
                for (int j = 0; j < s; j++)
                {
                    if (x + i < myb.Width && y + j < myb.Width)
                    { 
                        myb.SetPixel(x + i, y + j, Color.Yellow);
                }
            }
        }

           
            pictureBox1.Image = myb;
            //رسم المربع في الform
            Graphics b = this.CreateGraphics();
            b.FillRectangle(Brushes.Gray, 20, 120, s, s);
         //   for(x=0;x<80; x++)    myb.SetPixel(x, 10, Color.Red);
            //myb.SetPixel(10 ,y, Color.Red);
            //y = x;
            //myb.SetPixel(x,y, Color.Red);

        }


        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    }
