﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace النموذج_الثاني_المحاذره_السادسسه
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            openFileDialog1.Filter = "files|*.jpg;*png";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                 pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                string filname = openFileDialog1.FileName;
                Bitmap mybitmap = new Bitmap(filname);
                pictureBox1.Image = mybitmap;
                textBox1.Text = openFileDialog1.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
        
        }
    }
}

